# Contributing to cloudone-filestorage-plugins

:tada: Thank you for taking the time to contribute! :tada:

## How can I contribute?

- Fork this repository.
- Commit your code with a message that is structured according to the [Conventional Commits](https://www.conventionalcommits.org/en/v1.0.0/) specification.
- Submit a PR with the information requested in PR template.
